public enum BuildingType
{
    None,   // Pas de b�timent
    Town,    // Ville (Town1, Town2, etc.)
    Road,      // route
    Lumberjack,    // bucheron
    Temple,
    StoneMine,
    WoodPile,
    StonePile,
    ManaPile,
    Other // si erreur

}