using UnityEngine;

public enum BonusEffectType
{
    MoreManaPerTurn,
    ExtraClickPower,
    ResourceBoost,
    ReduceBuildingCost,
    ExtraPopulation,
    RevealMap,
    
}
