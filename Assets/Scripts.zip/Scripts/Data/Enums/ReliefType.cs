public enum ReliefType
{
    None,   
    Wood,
    Mountain,
    River,
    Other // si erreur

}