public enum ResourceType
{
    Gold,
    Wood,
    Stone,
    Mana
}
