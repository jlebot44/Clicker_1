public enum GroundType
{
    None,
    Grass,
    Other // si erreur

}