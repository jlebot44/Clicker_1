public enum BuildingType
{
    None,   // Pas de b�timent
    Capital,
    Town,    // Ville (Town1, Town2, etc.)
    Road,      // route
    Lumberjack,    // bucheron
    Temple,
    StoneMine,
    WoodPile,
    StonePile,
    ManaPile,
    BonusShrine, // non constructible : pour les bonus
    Other // si erreur

}